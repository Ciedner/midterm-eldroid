package com.mabale.animal.ciedneranimalnames

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.mabale.animal.ciedneranimalnames.AnimalAdapter.AnimalAdapter
import com.mabale.animal.ciedneranimalnames.databinding.ActivityManageBinding
import com.mabale.animal.ciedneranimalnames.list.Animals


class ManageBlockActivity : AppCompatActivity() {
    private lateinit var binding: ActivityManageBinding
    private lateinit var adapter: AnimalAdapter // Use your custom adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val preference = Preference(this)
        val blockedAnimalNames = preference.getBlockedAnimals().toList()

        // Initialize and set up your RecyclerView and adapter to display blocked animal names
        // Initialize and set up your RecyclerView and adapter to display blocked animal names
        binding.blockedAnimal.adapter = adapter
        binding.blockedAnimal.layoutManager = LinearLayoutManager(this)
    }
}