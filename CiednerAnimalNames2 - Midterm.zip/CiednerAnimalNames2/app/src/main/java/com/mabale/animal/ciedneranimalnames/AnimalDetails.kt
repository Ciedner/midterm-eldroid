package com.mabale.animal.ciedneranimalnames

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.mabale.animal.ciedneranimalnames.AnimalConstants.AnimalConstants
import com.mabale.animal.ciedneranimalnames.databinding.ActivityProfileBinding


class AnimalDetails : AppCompatActivity () {
    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

       val animalName = intent.getStringExtra("animalName")
        binding.name.text = animalName
        binding.description.text = "Description of $animalName"

        val name = intent.getStringExtra(AnimalConstants.PARAM_NAME)
        val desc = intent.getStringExtra(AnimalConstants.PARAM_DESC)

        val title ="$name"
        val add = "$desc"

        binding.name.text = title
        binding.description.text = add
    }
}