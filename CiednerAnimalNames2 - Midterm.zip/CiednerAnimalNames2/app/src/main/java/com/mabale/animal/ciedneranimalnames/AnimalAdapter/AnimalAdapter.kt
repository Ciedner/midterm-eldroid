package com.mabale.animal.ciedneranimalnames.AnimalAdapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mabale.animal.ciedneranimalnames.AnimalConstants.AnimalConstants
import com.mabale.animal.ciedneranimalnames.AnimalDetails
import com.mabale.animal.ciedneranimalnames.databinding.ItemAnimalsBinding
import com.mabale.animal.ciedneranimalnames.list.Animals

class AnimalAdapter(
    private val activity: Activity,
    private val animals: MutableList<Animals>
): RecyclerView.Adapter<AnimalAdapter.AnimalViewHolder>() {

    class AnimalViewHolder(
        private val activity: Activity,
        private val binding: ItemAnimalsBinding
    ): RecyclerView.ViewHolder(binding.root) {
        fun bind(animals: Animals) {
            val title = " ${animals.name}"
            binding.name.text = title
            binding.row.setOnClickListener {

                // Declaring Intent.
                val intent = Intent(
                    activity, // Context of the Current Activity.
                    AnimalDetails::class.java // Activity that we want to open.
                )
                intent.putExtra(AnimalConstants.PARAM_ID, animals.id)
                // Adding String type parameter from current Activity to ProfileActivity.
                intent.putExtra(AnimalConstants.PARAM_NAME, animals.name)
                intent.putExtra(AnimalConstants.PARAM_DESC, animals.description)
                // Open the ProfileActivity.
                activity.startActivity(intent)
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): AnimalViewHolder {
        val binding = ItemAnimalsBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AnimalViewHolder(activity, binding)
    }

    override fun getItemCount() = animals.size

    override fun onBindViewHolder(
        holder: AnimalViewHolder,
        position: Int
    ) {
        holder.bind(animals[position])
    }
}