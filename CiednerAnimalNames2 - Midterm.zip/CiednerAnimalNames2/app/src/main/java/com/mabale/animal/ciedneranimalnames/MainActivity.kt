package com.mabale.animal.ciedneranimalnames

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.mabale.animal.ciedneranimalnames.AnimalAdapter.AnimalAdapter
import com.mabale.animal.ciedneranimalnames.databinding.ActivityMainBinding
import com.mabale.animal.ciedneranimalnames.list.Animals

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

     binding.manageBlockButton.setOnClickListener {
         val intent = Intent(this, ManageBlockActivity::class.java)
         startActivity(intent)
     }

        val animals: MutableList<Animals> = ArrayList()


            animals.add(Animals(1,"Iring", "Pinaka cute na animal"))
            animals.add(Animals(2, "Iro", "cute na animal"))
            animals.add(Animals( 3, "Monkey", "animal ra"))
            animals.add(Animals( 4, "Kanding", "animal sad"))


        binding.animalList.layoutManager = LinearLayoutManager(this)
        binding.animalList.adapter = AnimalAdapter(
            this, // Adding this parameter since we need the context of the current screen.
            animals
        )
    }


}