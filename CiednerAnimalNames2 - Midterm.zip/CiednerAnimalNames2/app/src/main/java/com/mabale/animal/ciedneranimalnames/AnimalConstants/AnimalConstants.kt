package com.mabale.animal.ciedneranimalnames.AnimalConstants

class AnimalConstants {
    companion object {
        const val PARAM_NAME = "PARAM_NAME"
        const val PARAM_DESC = "PARAM_DESC"
        const val PARAM_ID = "PARAM_ID"
    }
}