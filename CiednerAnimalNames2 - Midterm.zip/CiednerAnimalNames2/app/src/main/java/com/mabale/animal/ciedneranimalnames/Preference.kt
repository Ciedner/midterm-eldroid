package com.mabale.animal.ciedneranimalnames

import android.content.Context

class Preference (private val context : Context){
    private val sharedPreferences = context.getSharedPreferences("AnimaBlockPrefs", Context.MODE_PRIVATE)

    fun getBlockedAnimals(): Set<String> {
        return sharedPreferences.getStringSet("blockedAnimals", emptySet()) ?: emptySet()
    }

    fun addBlockedAnimal(animalName: String) {
        val blockedAnimals = getBlockedAnimals().toMutableSet()
        blockedAnimals.add(animalName)
        sharedPreferences.edit().putStringSet("blockedAnimals", blockedAnimals).apply()
    }
}