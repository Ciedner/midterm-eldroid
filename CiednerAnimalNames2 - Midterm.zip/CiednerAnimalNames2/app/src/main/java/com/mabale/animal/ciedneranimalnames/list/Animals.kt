package com.mabale.animal.ciedneranimalnames.list

data class Animals (
    val id: Int,
    val name: String,
    val description: String
)